void proc(struct ele *up){

	up->next= *(up->y[0])+up->y[2];	
}

