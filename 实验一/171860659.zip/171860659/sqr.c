#include<stdio.h>
int main()
{
	unsigned int i,j;
	i=40000;
	j=i*i;
	printf("the 40000*40000 is %u\n",j);
	i=50000;
	j=i*i;
	printf("the 50000*50000 is %u\n",j);
	return 0;
}


